//quick hack to have a jquery var albeit using zepto
var jQuery=Zepto;